# Job Portal Backend

Flask-based backend system for job listings with MySQL and REST APIs.