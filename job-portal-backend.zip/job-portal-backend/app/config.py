class Config:
    SQLALCHEMY_DATABASE_URI = 'mysql://root:password@localhost/jobportal'
    SQLALCHEMY_TRACK_MODIFICATIONS = False